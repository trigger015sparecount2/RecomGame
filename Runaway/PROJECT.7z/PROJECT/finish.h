//*****************************************************************************
// �t�B�j�b�V��UI����(finish.h)
// Author : �O��q��
//*****************************************************************************

#ifndef _FINISH_H_
#define _FINISH_H_

#include "ui.h"

class CFinish :public CScene
{
public:
	CFinish(PRIORITY Priority);
	~CFinish();

	HRESULT Init(D3DXVECTOR3);	//������
	void Uninit();	//�I��
	void Update();	//�X�V
	void Draw();	//�`��

	void ZTexDraw() { ; }
	D3DXVECTOR3 GetPos() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	D3DXVECTOR3 GetRot() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	D3DXVECTOR3 GetPosOld() { return D3DXVECTOR3(0.0f, 0.0f, 0.0f); }
	float GetRadius() { return 0.0f; }
	void SetPos(D3DXVECTOR3) { ; }

	OBJTYPE GetObjType() { return OBJECTTYPE_UI; }

	static CFinish *Create();	//�쐬
private:
	int m_nTime;	//����
};
#endif